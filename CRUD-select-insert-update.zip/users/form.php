<form class="row g-3" action="<?php echo $form_action;?>" method="POST">
  <div class="col-md-6">
    <label for="inputEmail4" class="form-label">Nom</label>
    <input type="text" class="form-control" name="nom" value="<?php echo $auditeur['nom'];?>">
  </div>
  <div class="col-md-6">
    <label for="inputPassword4" class="form-label">Prenom</label>
    <input type="text" class="form-control" name="prenom" value="<?php echo $auditeur['prenom'];?>">
  </div>
  <div class="col-12">
    <label for="inputAddress" class="form-label">Email</label>
    <input type="email" class="form-control" id="inputEmail4" name="email" value="<?php echo $auditeur['email'];?>">
  </div>

  <div class="col-md-4">
    <label for="inputState" class="form-label">Libre</label>
    <select id="inputState" class="form-select" name="libre">
      <option value="1" selected>Oui</option>
      <option value="0">Non</option>
    </select>
  </div>


  <div class="col-12">
    <button type="submit" class="btn btn-primary">Sauver</button>
  </div>
</form>
