<?php
$stmt = $pdo->prepare('SELECT * FROM auditeurs');
$stmt->execute();
?>
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">First</th>
      <th scope="col">Last</th>
      <th scope="col">Handle</th>
      <th scope="col">Libre</th>
    </tr>
  </thead>
  <tbody>

    <?php
    while($aud = $stmt->fetch()){
      echo '<tr>
        <th scope="row"><a href="index.php?update='.$aud['id'].'">'.$aud['id'].'</a></th>
        <td>'.$aud['prenom'].'</td>
        <td>'.$aud['nom'].'</td>
        <td>'.$aud['email'].'</td>
        <td>'.$aud['libre'].'</td>
      </tr>';
    }

     ?>

  </tbody>
</table>
