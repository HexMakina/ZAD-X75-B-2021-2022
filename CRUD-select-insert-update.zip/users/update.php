<?php
require_once '../db.php';

$sql = 'UPDATE auditeurs SET nom = :name, prenom = :firstname, email=:email, libre=:libre WHERE id=:id';
$stmt = $pdo->prepare($sql);
$stmt->execute([
  'email' => $_POST['email'],
  'name' => $_POST['nom'],
  'firstname' => $_POST['prenom'],
  'libre' => $_POST['libre'],
  'id' => $_GET['id']]);

header('Location: ../index.php');

 ?>
