<?php
require_once '../db.php';

$id = $_GET['id'];
$name=$_POST['nom'];
$firstname=$_POST['prenom'];
$email=$_POST['email'];
$libre=$_POST['libre'];

$sql = 'UPDATE auditeurs SET nom = :name, prenom = :firstname, email=:email, libre=:libre WHERE id=:id';
$stmt = $pdo->prepare($sql);
$stmt->execute(['email' => $email, 'name' => $name, 'firstname' => $firstname, 'libre' => $libre, 'id' => $id]);

header('Location: ../index.php');

 ?>
