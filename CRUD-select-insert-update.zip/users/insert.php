<?php
require_once '../db.php';

$name=$_POST['nom'];
$firstname=$_POST['prenom'];
$email=$_POST['email'];
$libre=$_POST['libre'];

$sql = 'INSERT INTO auditeurs (nom, prenom, email, libre) VALUES (:name, :firstname, :email, :libre)';
$stmt = $pdo->prepare($sql);
$stmt->execute(['email' => $email, 'name' => $name, 'firstname' => $firstname, 'libre' => $libre]);

header('Location: ../index.php');

 ?>
